#pragma once

#include <vector>

template<typename T, typename Generator>
class Sequence {
private:
	std::vector<T> elements;
	Generator generator;
public:
	void generateNext(const int& numsToGenerate) {
		for (int i = 0; i < numsToGenerate;i++) {
			T next = generator();
			elements.push_back(next);
		}
	}

	typename std::vector<T>::iterator begin() {
		return this->elements.begin();
	}

	typename std::vector<T>::iterator end() {
		return this->elements.end();
	}
};